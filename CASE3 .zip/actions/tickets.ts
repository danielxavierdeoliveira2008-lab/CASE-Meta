"use server";

import { revalidatePath } from "next/cache";
import { addTicket } from "@/lib/storage";

export async function createTicketAction(formData: FormData) {
  const title = formData.get("title")?.toString().trim();
  const description = formData.get("description")?.toString().trim() || "";

  if (!title) {
    return { success: false, error: "O título do chamado é obrigatório." };
  }

  try {
    await addTicket({
      title,
      description,
    });

    revalidatePath("/");
    return { success: true };
  } catch (error) {
    console.error("Erro ao criar ticket via Server Action:", error);
    return {
      success: false,
      error: "Falha ao registrar chamado. Tente novamente.",
    };
  }
}
