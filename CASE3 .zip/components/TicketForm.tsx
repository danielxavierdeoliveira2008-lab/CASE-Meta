"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { createTicketAction } from "@/actions/tickets";
import { Loader2 } from "lucide-react";

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <button
      type="submit"
      disabled={pending}
      className="bg-meta-gradient text-white font-semibold py-3 px-4 rounded-xl shadow-md hover:opacity-90 transition-opacity focus:ring-4 focus:ring-meta-cyan/30 mt-2 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
    >
      {pending ? (
        <>
          <Loader2 className="w-5 h-5 animate-spin" />
          enviando chamado...
        </>
      ) : (
        "enviar chamado"
      )}
    </button>
  );
}

export default function TicketForm() {
  const [state, formAction] = useActionState(
    async (_prevState: unknown, formData: FormData) => {
      return await createTicketAction(formData);
    },
    null
  );

  return (
    <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
      <h2>abrir novo chamado</h2>

      {state?.error && (
        <div className="mt-4 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm font-medium">
          {state.error}
        </div>
      )}

      {state?.success && (
        <div className="mt-4 p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-600 text-sm font-medium">
          Chamado registrado com sucesso!
        </div>
      )}

      <form action={formAction} className="mt-6 flex flex-col gap-5">
        <div className="flex flex-col gap-1.5">
          <label
            htmlFor="ticket-title"
            className="text-sm font-medium text-meta-dark/80"
          >
            título do problema *
          </label>
          <input
            type="text"
            id="ticket-title"
            name="title"
            placeholder="Ex: Teclado não funciona"
            required
            className="px-4 py-3 bg-meta-light/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-meta-cyan focus:border-meta-cyan outline-none transition-all"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label
            htmlFor="ticket-description"
            className="text-sm font-medium text-meta-dark/80"
          >
            descrição
          </label>
          <textarea
            id="ticket-description"
            name="description"
            rows={3}
            placeholder="Descreva detalhes adicionais sobre o ocorrido"
            className="px-4 py-3 bg-meta-light/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-meta-cyan focus:border-meta-cyan outline-none transition-all resize-none text-sm"
          />
        </div>

        <SubmitButton />
      </form>
    </div>
  );
}
