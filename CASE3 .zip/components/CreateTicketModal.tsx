"use client";

import { useState, useTransition } from "react";
import { X, Loader2 } from "lucide-react";
import { createTicketAction } from "@/actions/tickets";

export default function CreateTicketModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const handleAction = (formData: FormData) => {
    setError(null);
    startTransition(async () => {
      const result = await createTicketAction(formData);
      if (result?.success) {
        setIsOpen(false);
      } else if (result?.error) {
        setError(result.error);
      }
    });
  };

  return (
    <>
      <button
        onClick={() => {
          setError(null);
          setIsOpen(true);
        }}
        className="bg-meta-gradient text-white font-bold py-3 px-8 rounded-full shadow-lg hover:scale-105 transition-transform active:scale-95 cursor-pointer"
      >
        + criar chamado
      </button>

      {/* Estrutura do Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Overlay com Blur */}
          <div
            className="absolute inset-0 bg-meta-dark/40 backdrop-blur-sm"
            onClick={() => !isPending && setIsOpen(false)}
          />

          {/* Card do Modal */}
          <div className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h2>abrir novo chamado</h2>
                <button
                  type="button"
                  disabled={isPending}
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors cursor-pointer disabled:opacity-50"
                >
                  <X size={20} className="text-meta-dark" />
                </button>
              </div>

              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-medium">
                  {error}
                </div>
              )}

              {/* Formulário integrado à Server Action */}
              <form action={handleAction} className="flex flex-col gap-5">
                <div className="flex flex-col gap-2">
                  <label
                    htmlFor="title"
                    className="text-sm font-semibold text-meta-dark/60 ml-1"
                  >
                    o que está acontecendo? *
                  </label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    placeholder="Ex: Monitor não liga"
                    required
                    disabled={isPending}
                    className="px-5 py-4 bg-meta-light rounded-2xl border border-slate-100 focus:ring-2 focus:ring-meta-cyan outline-none transition-all text-meta-dark disabled:opacity-50"
                  />
                </div>

                <div className="flex flex-col gap-2">
                  <label
                    htmlFor="description"
                    className="text-sm font-semibold text-meta-dark/60 ml-1"
                  >
                    detalhes do problema
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    rows={3}
                    placeholder="Ex: O monitor fica com tela preta e o led de energia pisca em laranja."
                    disabled={isPending}
                    className="px-5 py-3 bg-meta-light rounded-2xl border border-slate-100 focus:ring-2 focus:ring-meta-cyan outline-none transition-all text-meta-dark resize-none disabled:opacity-50 text-sm"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    disabled={isPending}
                    onClick={() => setIsOpen(false)}
                    className="flex-1 px-4 py-4 rounded-2xl font-bold text-meta-dark/60 hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isPending}
                    className="flex-[2] bg-meta-gradient text-white font-bold py-4 rounded-2xl shadow-md hover:opacity-90 transition-opacity flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
                  >
                    {isPending ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        enviando...
                      </>
                    ) : (
                      "enviar chamado"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
