import fs from "fs/promises";
import path from "path";
import { Ticket } from "@/types/ticket";

const TICKETS_FILE_PATH = path.join(process.cwd(), "data", "tickets.json");

export async function getTickets(): Promise<Ticket[]> {
  // Delay artificial de 2 segundos para evidenciar o estado de loading.tsx
  await new Promise((resolve) => setTimeout(resolve, 2000));

  try {
    const data = await fs.readFile(TICKETS_FILE_PATH, "utf-8");
    const tickets: Ticket[] = JSON.parse(data);
    return tickets;
  } catch (error) {
    console.error("Erro ao ler tickets do arquivo JSON:", error);
    return [];
  }
}

export async function addTicket(
  newTicketData: Omit<Ticket, "id" | "createdAt" | "status">
): Promise<Ticket> {
  let tickets: Ticket[] = [];

  try {
    const data = await fs.readFile(TICKETS_FILE_PATH, "utf-8");
    tickets = JSON.parse(data);
  } catch (error) {
    console.warn("Arquivo de tickets não encontrado ou vazio, iniciando novo array.", error);
    tickets = [];
  }

  const newTicket: Ticket = {
    id: `tkt-${Date.now()}`,
    title: newTicketData.title,
    description: newTicketData.description || "",
    status: "Aberto",
    createdAt: new Date().toISOString(),
  };

  // Insere no início do array para aparecer no topo da lista
  tickets.unshift(newTicket);

  await fs.writeFile(
    TICKETS_FILE_PATH,
    JSON.stringify(tickets, null, 2),
    "utf-8"
  );

  return newTicket;
}
