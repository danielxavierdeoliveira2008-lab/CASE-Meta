globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/9rwMafNeGrE_9t_5oTw00/_buildManifest.js",
    "static/9rwMafNeGrE_9t_5oTw00/_ssgManifest.js",
    "static/9rwMafNeGrE_9t_5oTw00/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0b5yd18v4zlw1.js",
    "static/chunks/00p-41jq4urj5.js",
    "static/chunks/09dnlovgebhgd.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-0-1oq~sok4s.7.js"
  ]
};
