1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0dbhjjzl8qfwv.js"],"default"]
3:I[37457,["/_next/static/chunks/0dbhjjzl8qfwv.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"9rwMafNeGrE_9t_5oTw00"}
