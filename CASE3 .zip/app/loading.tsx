import { Loader2 } from "lucide-react";

export default function Loading() {
  return (
    <main className="max-w-7xl mx-auto px-6 py-12 md:py-16">
      {/* Header com indicador sutil de carregamento */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-16">
        <div>
          <h1 className="text-3xl md:text-4xl font-semibold lowercase text-meta-dark">
            central de chamados
          </h1>
          <p className="text-meta-dark/60 text-lg mt-2">
            gerencie e acompanhe as solicitações de suporte <strong>ti</strong>.
          </p>
        </div>

        {/* Botão em estado de esqueleto */}
        <div className="h-12 w-48 rounded-full bg-slate-200/80 animate-pulse" />
      </header>

      {/* Seção Principal de Carregamento */}
      <section className="flex flex-col gap-8">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-semibold lowercase text-meta-dark flex items-center gap-2">
            fila de atendimento
            <Loader2 className="w-5 h-5 text-meta-cyan animate-spin inline-block ml-1" />
          </h2>
          <div className="h-px flex-grow bg-slate-200" />
          <div className="h-8 w-28 rounded-full bg-slate-200 animate-pulse" />
        </div>

        {/* Skeletons dos Tickets em Grid idêntico ao TicketList */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 animate-pulse flex flex-col justify-between h-56"
            >
              <div>
                {/* Badge de status skeleton */}
                <div className="w-24 h-6 rounded-full bg-slate-200 mb-6" />

                {/* Título skeleton */}
                <div className="w-4/5 h-6 rounded-lg bg-slate-200 mb-3" />

                {/* Descrição skeleton */}
                <div className="w-full h-4 rounded bg-slate-100 mb-2" />
                <div className="w-2/3 h-4 rounded bg-slate-100" />
              </div>

              {/* Rodapé do card skeleton */}
              <div className="flex justify-between items-center pt-4 border-t border-slate-50">
                <div className="w-20 h-3 rounded bg-slate-200" />
                <div className="w-16 h-3 rounded bg-slate-200" />
              </div>
            </div>
          ))}
        </div>
      </section>

      <footer className="mt-20 text-center text-meta-dark/20 text-xs font-medium">
        meta &copy; 2026 | internal systems engineering
      </footer>
    </main>
  );
}
